# Security Policy

Please do not report security vulnerabilities in public issues. Contact the repository maintainer privately through the security contact listed on the GitHub repository profile.

Never share bot tokens, session cookies, private server data, or personal information in a report. Rotate any token that may have been exposed.
