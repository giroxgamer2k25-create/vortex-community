# Roadmap

## v1.0.0 — Starter release
- [x] Ticket creation, claim and close
- [x] Basic moderation commands
- [x] Welcome messages
- [x] Starter virtual economy
- [x] Basic anti-spam
- [x] Setup and contribution documentation

## v1.1.0 — Reliability
- [ ] Automated tests for core utilities
- [ ] Ticket transcripts and configurable archive channel
- [ ] Audit log module
- [ ] Persistent rate limiting and structured logging
- [ ] Database adapter interface

## v1.2.0 — Community features
- [ ] Levels and configurable XP
- [ ] Reaction roles
- [ ] Suggestions and polls
- [ ] Per-guild configuration command

## v2.0.0 — Production hardening
- [ ] SQLite/PostgreSQL storage with migrations
- [ ] Automated backups and restore command
- [ ] Dashboard/API (optional)
- [ ] Localization (French and English)
