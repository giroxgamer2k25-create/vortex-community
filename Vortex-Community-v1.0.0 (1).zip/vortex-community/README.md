# Vortex Community

**A modular, open-source Discord community bot built with JavaScript and discord.js v14.**

Vortex Community provides reusable tools for Discord servers: private support tickets, moderation, welcome messages, a virtual economy, and basic anti-spam. It is designed to be configured and reused by different communities.

## Features

- 🎫 Private ticket channels with create, claim, and close controls
- 🛡️ Moderation: warn, timeout, ban, and purge
- 👋 Configurable welcome messages
- 🪙 Virtual economy with daily rewards and leaderboard
- 🚦 Configurable basic anti-spam
- ⚙️ Slash-command setup and per-server welcome configuration
- 🤝 GitHub issue templates, pull request template, and CI syntax check

## Requirements

- Node.js 20.11 or newer
- A Discord application and bot from the [Discord Developer Portal](https://discord.com/developers/applications)
- Bot invite scopes: `bot` and `applications.commands`
- Enable **Server Members Intent** and **Message Content Intent** in the Developer Portal

## Quick start

1. Download or clone this repository.
2. Install dependencies: `npm install`
3. Copy `.env.example` to `.env`.
4. Fill in `DISCORD_TOKEN`, `CLIENT_ID`, and `GUILD_ID`.
5. Register slash commands: `npm run deploy`
6. Start the bot: `npm start`

For development, run `npm run dev`. Check syntax with `npm run check`.

## Configuration

| Variable | Description |
|---|---|
| `DISCORD_TOKEN` | Bot token; keep it secret |
| `CLIENT_ID` | Discord application ID |
| `GUILD_ID` | Test server ID for guild command deployment |
| `TICKET_CATEGORY_ID` | Optional category for new tickets |
| `STAFF_ROLE_ID` | Optional staff role for ticket access and claim |
| `WELCOME_CHANNEL_ID` | Optional default welcome channel |
| `ANTISPAM_ENABLED` | Set to `false` to disable basic anti-spam |
| `ANTISPAM_WINDOW_MS` | Anti-spam time window in milliseconds |
| `ANTISPAM_MAX_MESSAGES` | Message threshold within the time window |

The bot creates `data/store.json` automatically. Back up the `data/` directory. Do not edit the file while the bot is running.

## Important limitations

This is an initial community release, not a fully hardened large-scale production service. JSON storage is intended for small deployments. Before large-scale use, migrate to SQLite/PostgreSQL, add backups, audit logging, tests, and operational monitoring. The anti-spam feature is intentionally basic and should be tuned for each community.

Use a private test server first and grant only the permissions the bot needs. Do not give Administrator without a specific reason.

## Contributing

Read [CONTRIBUTING.md](CONTRIBUTING.md) before opening a pull request. Real, useful contributions are welcome. Never submit secrets or private user data.

## License

MIT. See [LICENSE](LICENSE).
