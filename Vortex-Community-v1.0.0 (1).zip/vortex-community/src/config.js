import "dotenv/config";

const required = ["DISCORD_TOKEN", "CLIENT_ID", "GUILD_ID"];
for (const key of required) {
  if (!process.env[key]) {
    throw new Error(`Missing ${key}. Copy .env.example to .env and configure it.`);
  }
}

export const config = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID,
  ticketCategoryId: process.env.TICKET_CATEGORY_ID || null,
  staffRoleId: process.env.STAFF_ROLE_ID || null,
  welcomeChannelId: process.env.WELCOME_CHANNEL_ID || null,
  antispamEnabled: process.env.ANTISPAM_ENABLED !== "false",
  antispamWindowMs: Number(process.env.ANTISPAM_WINDOW_MS || 7000),
  antispamMaxMessages: Number(process.env.ANTISPAM_MAX_MESSAGES || 5)
};
