import {
  Client, GatewayIntentBits, Partials, Events, ChannelType,
  PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  EmbedBuilder
} from "discord.js";
import { config } from "./config.js";
import { db, loadStore } from "./store.js";

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel, Partials.Message]
});

const spamTracker = new Map();

function ticketButtons() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("ticket:create").setLabel("Create a ticket").setEmoji("🎫").setStyle(ButtonStyle.Primary)
  );
}

function ticketControls() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("ticket:claim").setLabel("Claim").setEmoji("🙋").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("ticket:close").setLabel("Close").setEmoji("🔒").setStyle(ButtonStyle.Danger)
  );
}

function isStaff(interaction) {
  const hasManageChannels = interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels) ?? false;
  const roles = interaction.member?.roles;
  const hasStaffRole = Array.isArray(roles)
    ? roles.includes(config.staffRoleId)
    : Boolean(roles?.cache?.has(config.staffRoleId));
  return hasManageChannels || (Boolean(config.staffRoleId) && hasStaffRole);
}

async function createTicket(interaction) {
  const existing = Object.values(db.tickets).find(t =>
    t.guildId === interaction.guildId && t.userId === interaction.user.id && !t.closed
  );
  if (existing) {
    return interaction.reply({ content: `You already have an open ticket: <#${existing.channelId}>`, ephemeral: true });
  }

  const safeName = interaction.user.username.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 18) || "member";
  const channel = await interaction.guild.channels.create({
    name: `ticket-${safeName}`,
    type: ChannelType.GuildText,
    parent: config.ticketCategoryId || undefined,
    topic: `Vortex ticket | owner:${interaction.user.id}`,
    permissionOverwrites: [
      { id: interaction.guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
      { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] },
      { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ReadMessageHistory] },
      ...(config.staffRoleId ? [{ id: config.staffRoleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] }] : [])
    ]
  });

  db.tickets[channel.id] = {
    guildId: interaction.guildId, channelId: channel.id,
    userId: interaction.user.id, claimedBy: null,
    createdAt: Date.now(), closed: false
  };
  await db.save();
  await channel.send({
    content: `<@${interaction.user.id}>${config.staffRoleId ? ` <@&${config.staffRoleId}>` : ""}`,
    embeds: [new EmbedBuilder().setColor(0x7957d5).setTitle("Support ticket").setDescription("Please explain your request. A team member will help you shortly.")],
    components: [ticketControls()]
  });
  return interaction.reply({ content: `Your ticket has been created: ${channel}`, ephemeral: true });
}

async function closeTicket(interaction) {
  const ticket = db.tickets[interaction.channelId];
  if (!ticket || ticket.closed) {
    return interaction.reply({ content: "This channel is not an open Vortex ticket.", ephemeral: true });
  }
  if (interaction.user.id !== ticket.userId && !isStaff(interaction)) {
    return interaction.reply({ content: "Only the ticket owner or staff can close this ticket.", ephemeral: true });
  }
  ticket.closed = true;
  ticket.closedAt = Date.now();
  await db.save();
  await interaction.reply({ content: "🔒 Ticket closed. This channel will be deleted in 10 seconds." });
  setTimeout(() => interaction.channel?.delete("Ticket closed").catch(() => {}), 10_000);
}

client.once(Events.ClientReady, readyClient => {
  console.log(`Vortex Community is online as ${readyClient.user.tag}`);
  readyClient.user.setActivity("your community | /help");
});

client.on(Events.GuildMemberAdd, async member => {
  const channelId = db.welcomeChannels[member.guild.id] || config.welcomeChannelId;
  if (!channelId) return;
  const channel = await member.guild.channels.fetch(channelId).catch(() => null);
  if (!channel?.isTextBased()) return;
  channel.send({
    embeds: [new EmbedBuilder().setColor(0x7957d5).setTitle("Welcome!")
      .setDescription(`Welcome ${member} to **${member.guild.name}**! You are member **${member.guild.memberCount}**.`)
      .setThumbnail(member.user.displayAvatarURL())]
  }).catch(() => {});
});

client.on(Events.MessageCreate, async message => {
  if (!config.antispamEnabled || !message.guild || message.author.bot) return;
  const now = Date.now();
  const key = `${message.guild.id}:${message.author.id}`;
  const recent = (spamTracker.get(key) || []).filter(t => now - t < config.antispamWindowMs);
  recent.push(now);
  spamTracker.set(key, recent);
  if (recent.length > config.antispamMaxMessages && !message.member?.permissions.has(PermissionFlagsBits.ManageMessages)) {
    await message.delete().catch(() => {});
    await message.channel.send({ content: `${message.author}, please slow down.` })
      .then(msg => setTimeout(() => msg.delete().catch(() => {}), 4000)).catch(() => {});
    spamTracker.set(key, []);
  }
});

client.on(Events.InteractionCreate, async interaction => {
  try {
    if (interaction.isButton()) {
      if (interaction.customId === "ticket:create") return await createTicket(interaction);
      if (interaction.customId === "ticket:close") return await closeTicket(interaction);
      if (interaction.customId === "ticket:claim") {
        const ticket = db.tickets[interaction.channelId];
        if (!ticket || ticket.closed) return interaction.reply({ content: "This is not an open ticket.", ephemeral: true });
        if (!isStaff(interaction)) return interaction.reply({ content: "Staff only.", ephemeral: true });
        if (ticket.claimedBy) return interaction.reply({ content: `Already claimed by <@${ticket.claimedBy}>.`, ephemeral: true });
        ticket.claimedBy = interaction.user.id;
        await db.save();
        return interaction.reply({ content: `🙋 Ticket claimed by ${interaction.user}.` });
      }
    }

    if (!interaction.isChatInputCommand()) return;
    const { commandName } = interaction;

    if (commandName === "ping") {
      return interaction.reply({ content: `Pong! Gateway: ${client.ws.ping} ms`, ephemeral: true });
    }

    if (commandName === "ticket-panel") {
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor(0x7957d5).setTitle("Vortex Support")
          .setDescription("Need help? Click below to open a private support ticket.")],
        components: [ticketButtons()]
      });
    }

    if (commandName === "ticket-close") return await closeTicket(interaction);

    if (commandName === "ticket-claim") {
      const ticket = db.tickets[interaction.channelId];
      if (!ticket || ticket.closed) return interaction.reply({ content: "This is not an open ticket.", ephemeral: true });
      if (!isStaff(interaction)) return interaction.reply({ content: "Staff only.", ephemeral: true });
      if (ticket.claimedBy) return interaction.reply({ content: `Already claimed by <@${ticket.claimedBy}>.`, ephemeral: true });
      ticket.claimedBy = interaction.user.id;
      await db.save();
      return interaction.reply({ content: `🙋 Ticket claimed by ${interaction.user}.` });
    }

    if (commandName === "warn") {
      const member = interaction.options.getMember("member");
      const user = interaction.options.getUser("member");
      const reason = interaction.options.getString("reason");
      if (!member) return interaction.reply({ content: "That member is not in this server.", ephemeral: true });
      if (user.id === interaction.user.id || user.id === client.user.id) return interaction.reply({ content: "You cannot warn yourself or the bot.", ephemeral: true });
      const list = db.warnings[user.id] || [];
      list.push({ guildId: interaction.guildId, moderatorId: interaction.user.id, reason, at: Date.now() });
      db.warnings[user.id] = list;
      await db.save();
      return interaction.reply({ content: `⚠️ ${user.tag} has been warned. Total recorded warnings: ${list.length}.` });
    }

    if (commandName === "timeout") {
      const member = interaction.options.getMember("member");
      const minutes = interaction.options.getInteger("minutes");
      const reason = interaction.options.getString("reason") || "No reason provided";
      if (!member) return interaction.reply({ content: "Member not found.", ephemeral: true });
      if (!member.moderatable) return interaction.reply({ content: "I cannot timeout this member. Check role hierarchy and permissions.", ephemeral: true });
      await member.timeout(minutes * 60_000, reason);
      return interaction.reply({ content: `⏳ ${member.user.tag} timed out for ${minutes} minute(s).` });
    }

    if (commandName === "ban") {
      const member = interaction.options.getMember("member");
      const reason = interaction.options.getString("reason") || "No reason provided";
      if (!member) return interaction.reply({ content: "Member not found.", ephemeral: true });
      if (!member.bannable) return interaction.reply({ content: "I cannot ban this member. Check role hierarchy and permissions.", ephemeral: true });
      await member.ban({ reason });
      return interaction.reply({ content: `🔨 ${member.user.tag} has been banned.` });
    }

    if (commandName === "purge") {
      const amount = interaction.options.getInteger("amount");
      const deleted = await interaction.channel.bulkDelete(amount, true);
      return interaction.reply({ content: `🧹 Deleted ${deleted.size} message(s).`, ephemeral: true });
    }

    if (commandName === "balance") {
      const user = interaction.options.getUser("member") || interaction.user;
      const key = `${interaction.guildId}:${user.id}`;
      const coins = db.economy[key]?.coins || 0;
      return interaction.reply({ content: `🪙 **${user.username}** has **${coins}** V-Coins.`, ephemeral: true });
    }

    if (commandName === "daily") {
      const key = `${interaction.guildId}:${interaction.user.id}`;
      const account = db.economy[key] || { coins: 0, lastDaily: 0 };
      const day = 86_400_000;
      const remaining = day - (Date.now() - account.lastDaily);
      if (remaining > 0) {
        const hours = Math.floor(remaining / 3_600_000);
        const minutes = Math.ceil((remaining % 3_600_000) / 60_000);
        return interaction.reply({ content: `Your next daily reward is available in ${hours}h ${minutes}m.`, ephemeral: true });
      }
      account.coins += 100;
      account.lastDaily = Date.now();
      db.economy[key] = account;
      await db.save();
      return interaction.reply({ content: `🎁 You received **100 V-Coins**! New balance: **${account.coins}**.`, ephemeral: true });
    }

    if (commandName === "leaderboard") {
      const prefix = `${interaction.guildId}:`;
      const rows = Object.entries(db.economy)
        .filter(([key]) => key.startsWith(prefix))
        .sort((a, b) => b[1].coins - a[1].coins).slice(0, 10);
      const description = rows.length
        ? rows.map(([key, value], i) => `**${i + 1}.** <@${key.slice(prefix.length)}> — ${value.coins} V-Coins`).join("\n")
        : "No economy data yet. Use `/daily` to get started.";
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(0x7957d5).setTitle("Vortex Leaderboard").setDescription(description)] });
    }

    if (commandName === "welcome-setup") {
      const channel = interaction.options.getChannel("channel");
      db.welcomeChannels[interaction.guildId] = channel.id;
      await db.save();
      return interaction.reply({ content: `Welcome messages will be sent in ${channel}.`, ephemeral: true });
    }
  } catch (error) {
    console.error("Interaction error:", error);
    const payload = { content: "An error occurred. Check the bot logs; if it continues, open a GitHub issue without sharing secrets.", ephemeral: true };
    if (interaction.replied || interaction.deferred) await interaction.followUp(payload).catch(() => {});
    else await interaction.reply(payload).catch(() => {});
  }
});

await loadStore();
await client.login(config.token);
