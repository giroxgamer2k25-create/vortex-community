import { REST, Routes } from "discord.js";
import { config } from "./config.js";
import { commands } from "./commands.js";

const rest = new REST({ version: "10" }).setToken(config.token);

try {
  console.log(`Registering ${commands.length} guild commands...`);
  await rest.put(
    Routes.applicationGuildCommands(config.clientId, config.guildId),
    { body: commands }
  );
  console.log("Slash commands registered successfully.");
} catch (error) {
  console.error("Command deployment failed:", error);
  process.exitCode = 1;
}
