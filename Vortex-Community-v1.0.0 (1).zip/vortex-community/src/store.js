import { mkdir, readFile, writeFile, rename } from "node:fs/promises";
import path from "node:path";

const dataDir = path.resolve("data");
const dataFile = path.join(dataDir, "store.json");
const initial = {
  tickets: {},
  warnings: {},
  economy: {},
  welcomeChannels: {}
};

let state = structuredClone(initial);
let writeQueue = Promise.resolve();

export async function loadStore() {
  await mkdir(dataDir, { recursive: true });
  try {
    const raw = await readFile(dataFile, "utf8");
    state = { ...structuredClone(initial), ...JSON.parse(raw) };
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    await persist();
  }
}

async function persist() {
  const snapshot = JSON.stringify(state, null, 2);
  const tempFile = `${dataFile}.tmp`;
  await writeFile(tempFile, snapshot, "utf8");
  await rename(tempFile, dataFile);
}

export function saveStore() {
  writeQueue = writeQueue.then(persist);
  return writeQueue;
}

export const db = {
  get tickets() { return state.tickets; },
  get warnings() { return state.warnings; },
  get economy() { return state.economy; },
  get welcomeChannels() { return state.welcomeChannels; },
  save: saveStore
};
