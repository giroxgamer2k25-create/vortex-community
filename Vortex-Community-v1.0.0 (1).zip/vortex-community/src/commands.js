import {
  SlashCommandBuilder, PermissionFlagsBits, ChannelType
} from "discord.js";

export const commands = [
  new SlashCommandBuilder().setName("ping").setDescription("Check the bot response time."),
  new SlashCommandBuilder().setName("ticket-panel").setDescription("Post the ticket creation panel.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder().setName("ticket-close").setDescription("Close the ticket channel."),
  new SlashCommandBuilder().setName("ticket-claim").setDescription("Claim this ticket.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  new SlashCommandBuilder().setName("warn").setDescription("Record a warning for a member.")
    .addUserOption(o => o.setName("member").setDescription("Member to warn").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  new SlashCommandBuilder().setName("timeout").setDescription("Timeout a member.")
    .addUserOption(o => o.setName("member").setDescription("Member to timeout").setRequired(true))
    .addIntegerOption(o => o.setName("minutes").setDescription("Duration in minutes").setMinValue(1).setMaxValue(40320).setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  new SlashCommandBuilder().setName("ban").setDescription("Ban a member.")
    .addUserOption(o => o.setName("member").setDescription("Member to ban").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  new SlashCommandBuilder().setName("purge").setDescription("Delete recent messages.")
    .addIntegerOption(o => o.setName("amount").setDescription("Number of messages (1–100)").setMinValue(1).setMaxValue(100).setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  new SlashCommandBuilder().setName("balance").setDescription("Show a virtual currency balance.")
    .addUserOption(o => o.setName("member").setDescription("Member to check").setRequired(false)),
  new SlashCommandBuilder().setName("daily").setDescription("Claim your daily virtual reward."),
  new SlashCommandBuilder().setName("leaderboard").setDescription("Show the server economy leaderboard."),
  new SlashCommandBuilder().setName("welcome-setup").setDescription("Choose the welcome channel.")
    .addChannelOption(o => o.setName("channel").setDescription("Welcome channel").addChannelTypes(ChannelType.GuildText).setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
].map(command => command.toJSON());
