---
name: Bug report
about: Report a reproducible problem
title: "[Bug]: "
labels: bug
---

## What happened?

## Steps to reproduce

## Expected behavior

## Environment
- Node.js version:
- Vortex Community version:
- discord.js version:

## Logs
Remove tokens, IDs, personal data and private server information before posting.
