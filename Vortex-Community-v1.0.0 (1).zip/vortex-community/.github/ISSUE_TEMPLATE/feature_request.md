---
name: Feature request
about: Suggest a useful improvement
title: "[Feature]: "
labels: enhancement
---

## Problem this solves

## Proposed solution

## Who would benefit?

## Alternatives considered
