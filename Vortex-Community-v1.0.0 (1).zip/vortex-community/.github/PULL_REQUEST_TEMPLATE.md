## Summary
Describe what this pull request changes and why.

## Testing
- [ ] `npm run check` passes
- [ ] Discord behavior tested in a private test server (if applicable)

## Checklist
- [ ] No secrets, tokens, or private user data included
- [ ] Documentation updated where needed
- [ ] Change is focused and backward-compatible, or breaking changes are explained
