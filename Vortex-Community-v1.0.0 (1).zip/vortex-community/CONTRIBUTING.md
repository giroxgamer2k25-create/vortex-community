# Contributing to Vortex Community

Thanks for considering a contribution!

1. Open an issue describing the bug or proposed improvement.
2. Keep changes focused and explain the user benefit.
3. Use clear names and follow the existing JavaScript style.
4. Run `npm run check` before opening a pull request.
5. Include manual test steps for Discord interactions.
6. Never include bot tokens, server secrets, personal data or real user message contents in issues or commits.

Pull requests are reviewed on their merits. Please do not submit empty, duplicated or artificially split changes to inflate contribution counts.
